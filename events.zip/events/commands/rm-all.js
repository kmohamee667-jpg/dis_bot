const { EmbedBuilder, MessageFlags } = require('discord.js');

const ADMIN_USERNAME = 'khal3d0047';

module.exports = {
    name: 'rm-all',
    async execute(message, client, allowedGuildId) {
        if (message.author.username !== ADMIN_USERNAME) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription("❌ You don't have permission to use this command.")
                        .setColor('#E74C3C')
                ]
            }).catch(() => null);
        }

        if (allowedGuildId && message.guildId !== allowedGuildId) {
            return await message.reply({
                content: '❌ **No Permission to work here!**',
                flags: [MessageFlags.Ephemeral]
            }).catch(() => { });
        }

        const channels = message.guild.channels.cache;
        channels.forEach(channel => {
            if (channel.id === '1486464432468000778') return;
            channel.delete()
                .then(deleted => console.log(`تم حذف القناة: ${deleted.name}`))
                .catch(console.error);
        });

        message.reply("تم بدء عملية حذف القنوات...");
    }
};
