const { EmbedBuilder } = require('discord.js');
const { isAdmin } = require('../../utils/admin-check');
const { logAction } = require('../../utils/logger');
const timerManager = require('../../utils/timerManager');

module.exports = {
    name: 'مسح',
    async execute(message, client, allowedGuildId) {
        if (allowedGuildId && message.guildId !== allowedGuildId) {
            return await message.reply({
                content: '❌ **No Permission to work here!**',
                flags: [MessageFlags.Ephemeral]
            }).catch(() => { });
        }

        if (!await isAdmin(message, 'مسح')) {
            const denyMsg = await message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription("❌ You don't have permission to use this command.")
                        .setColor('#E74C3C')
                ]
            }).catch(() => null);

            if (denyMsg) setTimeout(() => denyMsg.delete().catch(() => { }), 4000);
            return;
        }

        const content = message.content.trim();
        const parts = content.split(' ');
        let count = 100;
        if (parts[1]) {
            const parsed = parseInt(parts[1]);
            if (!isNaN(parsed) && parsed > 0) {
                count = parsed; // No limit for full channel clear
            }
        } else {
            count = 999; // Delete all by default
        }

        const protectedIds = new Set();
        for (const [, timer] of timerManager.activeTimers) {
            if (timer.messageId) protectedIds.add(String(timer.messageId));
            if (timer.messageObj?.id) protectedIds.add(String(timer.messageObj.id));
        }

        let fetched;
        try {
            fetched = await message.channel.messages.fetch({ limit: count });
        } catch (e) {
            console.error('[مسح] Failed to fetch messages:', e);
            return;
        }

        const toDelete = fetched.filter(msg => !protectedIds.has(msg.id));

        let deletedCount = 0;
        try {
            const bulkDeleted = await message.channel.bulkDelete(toDelete, true);
            deletedCount = bulkDeleted.size;
        } catch (e) {
            console.error('[مسح] Bulk delete failed:', e);
        }

        const confirmEmbed = new EmbedBuilder()
            .setTitle('🗑️ تم المسح')
            .setDescription(`تم مسح **${deletedCount}** رسالة بواسطة ${message.author}`)
            .setColor('#9B59B6')
            .setFooter({ text: 'Galaxy Moderation System' })
            .setTimestamp();

        const confirmMsg = await message.channel.send({ embeds: [confirmEmbed] }).catch(() => null);
        if (confirmMsg) setTimeout(() => confirmMsg.delete().catch(() => { }), 5000);

        await logAction(client, message.guildId, {
            title: '🗑️ تنفيذ أمر مسح الرسائل',
            color: '#9B59B6',
            user: message.author,
            fields: [
                { name: '📺 القناة', value: `<#${message.channelId}>`, inline: true },
                { name: '🔢 عدد الرسائل المحذوفة', value: `\`${deletedCount}\``, inline: true },
                { name: '🛡️ رسائل محمية (تايمر)', value: `\`${protectedIds.size}\``, inline: true },
            ]
        }).catch(() => { });
    }
};
