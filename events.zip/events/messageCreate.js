const { readdirSync } = require('fs');
const path = require('path');
const { EmbedBuilder, MessageFlags } = require('discord.js');
const { isAdmin } = require('../utils/admin-check');

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        if (message.author.bot) return;

        const allowedGuildId = process.env.GUILD_ID;
        const content = message.content.trim();

        const commandsDir = path.join(__dirname, 'commands');
        console.log('Checking commands for:', content);
        const commandFiles = readdirSync(commandsDir).filter(file => file.endsWith('.js'));
        console.log('Found files:', commandFiles);
        
        for (const file of commandFiles) {
            const commandName = path.parse(file).name;
            const trigger = content.startsWith(`!${commandName}`) ? `!${commandName}` : commandName;
            console.log('Checking trigger:', trigger, 'for command:', commandName);
            
            if (content === trigger || content.startsWith(trigger + ' ')) {
                const command = require(path.join(commandsDir, file));
                console.log('Executing command:', commandName);
                await command.execute(message, client, allowedGuildId);
                return;
            }
        }
        console.log('No command matched');

        // مسح keyword
        if (content === 'مسح' || content.startsWith('مسح ')) {
            const mas7Command = require('./commands/mas7');
            await mas7Command.execute(message, client, allowedGuildId);
        }
    }
};

